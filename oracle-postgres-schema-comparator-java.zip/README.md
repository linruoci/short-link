# Oracle ↔ PostgreSQL Schema Comparator (Java)

Java 17 + JDBC CLI utility. It reads metadata only and creates an offline HTML report inspired by the supplied `table-structure-differences.html` layout.

## Included comparison
- Tables present only on either side
- Column presence, ordinal position, type, length, scale, NOT NULL and default
- Indexes (unique flag + ordered column signature; index names need not match)
- Primary keys and foreign keys (type + columns + referenced table/columns)
- Search, category tabs, filters, expandable table groups, print / Save as PDF
- HTML embeds the full report JSON and works offline

## Requirements
- JDK 17+
- Maven 3.9+
- Network access to Maven repositories at build time, or pre-populated Maven cache
- Oracle and PostgreSQL JDBC connectivity from the machine running the tool

## 1. Configure
Edit `config/application.properties`:
- `oracle.url`, `oracle.username`, `oracle.password`, `oracle.schema`
- `postgres.url`, `postgres.username`, `postgres.password`, `postgres.schema`
- labels and report output path

Do not commit real passwords. For production, inject credentials from environment/secret manager and restrict the database account to metadata visibility.

## 2. Build
```bash
mvn clean package
```
Creates:
`target/oracle-postgres-schema-comparator-1.0.0.jar`

## 3. Run
```bash
java -jar target/oracle-postgres-schema-comparator-1.0.0.jar
```
Or provide another properties file:
```bash
java -jar target/oracle-postgres-schema-comparator-1.0.0.jar /path/to/application.properties
```
Then open the generated `reports/schema-comparison.html` in a browser.

## Important notes / limitations
1. Metadata visibility depends on the database account. Oracle `DatabaseMetaData` only returns objects visible to the user; PostgreSQL likewise depends on privileges.
2. The initial version compares tables and direct column metadata, indexes, primary keys and foreign keys. It does not compare table data, views, sequences, triggers, stored procedures, grants, partitions, CHECK constraints or physical storage parameters.
3. Index comparison uses uniqueness and ordered column list. Expression/functional indexes, partial indexes, included columns, operator classes and storage parameters need a database-specific extension.
4. Oracle `NUMBER` and PostgreSQL integer/numeric types are not always semantically interchangeable. The tool does not automatically mark ambiguous numeric mappings as equivalent. Review these manually.
5. Default expressions are compared as normalized strings. Equivalent expressions such as Oracle and PostgreSQL sequence/default expressions may still be flagged.
6. Identifier matching is case-insensitive by default. This is convenient for Oracle uppercase names vs PostgreSQL lowercase names, but quoted case-sensitive identifiers may need `compare.ignoreCase=false`.
7. JDBC metadata type/size representations differ by driver version. Validate representative objects against each database's native catalog views before relying on the report for a production migration.

## Security
- The tool performs metadata reads only.
- It does not execute DDL or alter database objects.
- Avoid putting passwords in source control or sharing generated config files containing credentials.

## Type mapping behavior in v1
- `VARCHAR2` / `NVARCHAR2` are normalized to `VARCHAR`; length is still compared.
- PostgreSQL `INT8` / `INT4` driver names normalize to `BIGINT` / `INTEGER`.
- `NUMBER` is not blindly treated as PostgreSQL `BIGINT` or `NUMERIC`; ambiguous mappings remain visible for review.
- `CLOB` ↔ `TEXT` and `BLOB` ↔ `BYTEA` are treated as common LOB-family mappings, but validate encoding/length/application semantics separately.
