package com.example.schemacomparator;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

import java.io.InputStream;
import java.nio.file.*;
import java.sql.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class Main {
    private static final ObjectMapper JSON = new ObjectMapper().enable(SerializationFeature.INDENT_OUTPUT);

    public static void main(String[] args) {
        try {
            Path configPath = args.length > 0 ? Paths.get(args[0]) : Paths.get("config/application.properties");
            Properties p = new Properties();
            try (InputStream in = Files.newInputStream(configPath)) { p.load(in); }

            DbConfig oracle = new DbConfig(
                    required(p, "oracle.url"), required(p, "oracle.username"),
                    required(p, "oracle.password"), required(p, "oracle.schema"),
                    p.getProperty("oracle.label", "Oracle"));
            DbConfig postgres = new DbConfig(
                    required(p, "postgres.url"), required(p, "postgres.username"),
                    required(p, "postgres.password"), required(p, "postgres.schema"),
                    p.getProperty("postgres.label", "PostgreSQL"));

            boolean ignoreCase = Boolean.parseBoolean(p.getProperty("compare.ignoreCase", "true"));
            String title = p.getProperty("report.title", "Oracle vs PostgreSQL Schema Comparison");
            Path output = Paths.get(p.getProperty("report.output", "./reports/schema-comparison.html"));
            Files.createDirectories(output.toAbsolutePath().getParent());

            System.out.println("Connecting to source and target databases...");
            SchemaSnapshot left;
            SchemaSnapshot right;
            try (Connection c1 = DriverManager.getConnection(oracle.url(), oracle.username(), oracle.password());
                 Connection c2 = DriverManager.getConnection(postgres.url(), postgres.username(), postgres.password())) {
                left = MetadataReader.read(c1, oracle);
                right = MetadataReader.read(c2, postgres);
            }

            Map<String, Object> report = ComparatorEngine.compare(left, right, ignoreCase, title);
            report.put("generated", LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
            report.put("sourceLabel", oracle.label());
            report.put("targetLabel", postgres.label());

            String json = JSON.writeValueAsString(report).replace("</", "<\\/");
            String template;
            try (InputStream in = Main.class.getResourceAsStream("/report-template.html")) {
                if (in == null) throw new IllegalStateException("Missing report-template.html");
                template = new String(in.readAllBytes(), java.nio.charset.StandardCharsets.UTF_8);
            }
            String html = template.replace("__REPORT_TITLE__", Html.escape(title))
                    .replace("__REPORT_JSON__", json);

            Files.writeString(output, html, java.nio.charset.StandardCharsets.UTF_8);
            System.out.println("Comparison completed.");
            System.out.println("Tables: " + ((Map<?, ?>) report.get("stats")).get("tables")
                    + ", changed: " + ((Map<?, ?>) report.get("stats")).get("changedTables"));
            System.out.println("HTML report: " + output.toAbsolutePath());
        } catch (Exception e) {
            System.err.println("Comparison failed: " + e.getMessage());
            e.printStackTrace(System.err);
            System.exit(1);
        }
    }

    private static String required(Properties p, String key) {
        String value = p.getProperty(key);
        if (value == null || value.isBlank()) throw new IllegalArgumentException("Missing config property: " + key);
        return value.trim();
    }
}

record DbConfig(String url, String username, String password, String schema, String label) {}
record ColumnMeta(String name, int ordinal, String typeName, int jdbcType, int size,
                  int scale, boolean nullable, String defaultValue) {}
record IndexMeta(String name, boolean unique, List<String> columns) {}
record ConstraintMeta(String name, String type, List<String> columns, String referenceTable,
                      List<String> referenceColumns) {}
record TableMeta(String schema, String name, List<ColumnMeta> columns,
                 List<IndexMeta> indexes, List<ConstraintMeta> constraints) {}
record SchemaSnapshot(String label, String schema, Map<String, TableMeta> tables) {}

class MetadataReader {
    static SchemaSnapshot read(Connection c, DbConfig cfg) throws SQLException {
        DatabaseMetaData md = c.getMetaData();
        Map<String, TableMeta> tables = new TreeMap<>(String.CASE_INSENSITIVE_ORDER);

        try (ResultSet rs = md.getTables(c.getCatalog(), cfg.schema(), "%", new String[]{"TABLE"})) {
            while (rs.next()) {
                String schema = rs.getString("TABLE_SCHEM");
                String table = rs.getString("TABLE_NAME");
                if (table == null) continue;
                List<ColumnMeta> columns = readColumns(md, c, schema, table);
                List<IndexMeta> indexes = readIndexes(md, c, schema, table);
                List<ConstraintMeta> constraints = readConstraints(md, c, schema, table);
                tables.put(table, new TableMeta(schema, table, columns, indexes, constraints));
            }
        }
        return new SchemaSnapshot(cfg.label(), cfg.schema(), tables);
    }

    private static List<ColumnMeta> readColumns(DatabaseMetaData md, Connection c, String schema, String table)
            throws SQLException {
        List<ColumnMeta> result = new ArrayList<>();
        try (ResultSet rs = md.getColumns(c.getCatalog(), schema, table, "%")) {
            while (rs.next()) {
                String type = rs.getString("TYPE_NAME");
                int jdbcType = rs.getInt("DATA_TYPE");
                int size = rs.getInt("COLUMN_SIZE");
                int scale = rs.getInt("DECIMAL_DIGITS");
                int nullableCode = rs.getInt("NULLABLE");
                boolean nullable = nullableCode != DatabaseMetaData.columnNoNulls;
                String def = rs.getString("COLUMN_DEF");
                int ordinal = rs.getInt("ORDINAL_POSITION");
                result.add(new ColumnMeta(rs.getString("COLUMN_NAME"), ordinal, type, jdbcType,
                        size, scale, nullable, def));
            }
        }
        result.sort(Comparator.comparingInt(ColumnMeta::ordinal));
        return result;
    }

    private static List<IndexMeta> readIndexes(DatabaseMetaData md, Connection c, String schema, String table)
            throws SQLException {
        Map<String, List<String>> cols = new LinkedHashMap<>();
        Map<String, Boolean> unique = new HashMap<>();
        Map<String, TreeMap<Short, String>> ordered = new HashMap<>();
        try (ResultSet rs = md.getIndexInfo(c.getCatalog(), schema, table, false, false)) {
            while (rs.next()) {
                String name = rs.getString("INDEX_NAME");
                String col = rs.getString("COLUMN_NAME");
                if (name == null || col == null) continue;
                unique.put(name, !rs.getBoolean("NON_UNIQUE"));
                ordered.computeIfAbsent(name, k -> new TreeMap<>()).put(rs.getShort("ORDINAL_POSITION"), col);
            }
        }
        for (var e : ordered.entrySet()) cols.put(e.getKey(), new ArrayList<>(e.getValue().values()));
        List<IndexMeta> result = new ArrayList<>();
        cols.forEach((name, columns) -> result.add(new IndexMeta(name, unique.getOrDefault(name, false), columns)));
        result.sort(Comparator.comparing(IndexMeta::name, String.CASE_INSENSITIVE_ORDER));
        return result;
    }

    private static List<ConstraintMeta> readConstraints(DatabaseMetaData md, Connection c, String schema, String table)
            throws SQLException {
        List<ConstraintMeta> result = new ArrayList<>();
        Map<String, TreeMap<Short, String>> pk = new LinkedHashMap<>();
        try (ResultSet rs = md.getPrimaryKeys(c.getCatalog(), schema, table)) {
            while (rs.next()) pk.computeIfAbsent(rs.getString("PK_NAME"), k -> new TreeMap<>())
                    .put(rs.getShort("KEY_SEQ"), rs.getString("COLUMN_NAME"));
        }
        pk.forEach((name, columns) -> result.add(new ConstraintMeta(name == null ? "PRIMARY_KEY" : name,
                "PRIMARY KEY", new ArrayList<>(columns.values()), null, List.of())));

        Map<String, TreeMap<Short, String>> fkCols = new LinkedHashMap<>();
        Map<String, TreeMap<Short, String>> fkRefCols = new LinkedHashMap<>();
        Map<String, String> fkRefTables = new LinkedHashMap<>();
        try (ResultSet rs = md.getImportedKeys(c.getCatalog(), schema, table)) {
            while (rs.next()) {
                String name = rs.getString("FK_NAME");
                if (name == null) name = "FK_" + rs.getString("PKTABLE_NAME");
                final String key = name;
                fkCols.computeIfAbsent(key, k -> new TreeMap<>()).put(rs.getShort("KEY_SEQ"), rs.getString("FKCOLUMN_NAME"));
                fkRefCols.computeIfAbsent(key, k -> new TreeMap<>()).put(rs.getShort("KEY_SEQ"), rs.getString("PKCOLUMN_NAME"));
                fkRefTables.put(key, rs.getString("PKTABLE_NAME"));
            }
        }
        fkCols.forEach((name, columns) -> result.add(new ConstraintMeta(name, "FOREIGN KEY",
                new ArrayList<>(columns.values()), fkRefTables.get(name),
                new ArrayList<>(fkRefCols.get(name).values()))));
        result.sort(Comparator.comparing(ConstraintMeta::type).thenComparing(ConstraintMeta::name));
        return result;
    }
}

class ComparatorEngine {
    static Map<String, Object> compare(SchemaSnapshot left, SchemaSnapshot right, boolean ignoreCase, String title) {
        Map<String, TableMeta> l = normalize(left.tables(), ignoreCase);
        Map<String, TableMeta> r = normalize(right.tables(), ignoreCase);
        Set<String> keys = new TreeSet<>();
        keys.addAll(l.keySet()); keys.addAll(r.keySet());
        List<Map<String, Object>> tables = new ArrayList<>();

        int common = 0, onlyLeft = 0, onlyRight = 0, changed = 0, detailed = 0;
        int columnChanges = 0, indexChanges = 0, constraintChanges = 0;
        for (String key : keys) {
            TableMeta a = l.get(key), b = r.get(key);
            Map<String, Object> t = new LinkedHashMap<>();
            TableMeta base = a != null ? a : b;
            t.put("schema", base.schema()); t.put("name", base.name());
            t.put("left", a == null ? "N/A" : a.name());
            t.put("right", b == null ? "N/A" : b.name());
            if (a == null) { t.put("status", "right"); onlyRight++; t.put("columns", List.of()); t.put("expanded", false); t.put("changed", false); }
            else if (b == null) { t.put("status", "left"); onlyLeft++; t.put("columns", List.of()); t.put("expanded", false); t.put("changed", false); }
            else {
                common++; detailed++;
                t.put("status", "both");
                List<Map<String, Object>> columns = compareColumns(a, b, ignoreCase);
                List<Map<String, Object>> indexes = compareIndexes(a, b, ignoreCase);
                List<Map<String, Object>> constraints = compareConstraints(a, b, ignoreCase);
                boolean cChanged = columns.stream().anyMatch(x -> Boolean.TRUE.equals(x.get("changed")));
                boolean iChanged = indexes.stream().anyMatch(x -> !"MATCHED".equals(x.get("status")));
                boolean kChanged = constraints.stream().anyMatch(x -> !"MATCHED".equals(x.get("status")));
                if (cChanged || iChanged || kChanged) changed++;
                columnChanges += (int) columns.stream().filter(x -> Boolean.TRUE.equals(x.get("changed"))).count();
                indexChanges += (int) indexes.stream().filter(x -> !"MATCHED".equals(x.get("status"))).count();
                constraintChanges += (int) constraints.stream().filter(x -> !"MATCHED".equals(x.get("status"))).count();
                t.put("columns", columns); t.put("indexes", indexes); t.put("constraints", constraints);
                t.put("expanded", true); t.put("changed", cChanged || iChanged || kChanged);
                t.put("counts", Map.of("leftColumns", a.columns().size(), "rightColumns", b.columns().size(),
                        "columnChanges", (int) columns.stream().filter(x -> Boolean.TRUE.equals(x.get("changed"))).count(),
                        "leftIndexes", a.indexes().size(), "rightIndexes", b.indexes().size()));
            }
            tables.add(t);
        }
        Map<String, Object> stats = new LinkedHashMap<>();
        stats.put("tables", keys.size()); stats.put("common", common);
        stats.put("onlyLeftTables", onlyLeft); stats.put("onlyRightTables", onlyRight);
        stats.put("changedTables", changed); stats.put("detailedTables", detailed);
        stats.put("columnChanges", columnChanges); stats.put("indexChanges", indexChanges);
        stats.put("constraintChanges", constraintChanges);
        Map<String, Object> report = new LinkedHashMap<>();
        report.put("title", title); report.put("leftLabel", left.label()); report.put("rightLabel", right.label());
        report.put("leftSchema", left.schema()); report.put("rightSchema", right.schema());
        report.put("stats", stats); report.put("tables", tables);
        return report;
    }

    private static Map<String, TableMeta> normalize(Map<String, TableMeta> src, boolean ignoreCase) {
        Map<String, TableMeta> out = new TreeMap<>();
        src.forEach((k, v) -> out.put(ignoreCase ? k.toUpperCase(Locale.ROOT) : k, v));
        return out;
    }

    private static List<Map<String, Object>> compareColumns(TableMeta a, TableMeta b, boolean ignoreCase) {
        Map<String, ColumnMeta> ac = columnMap(a.columns(), ignoreCase), bc = columnMap(b.columns(), ignoreCase);
        Set<String> names = new TreeSet<>(); names.addAll(ac.keySet()); names.addAll(bc.keySet());
        List<Map<String, Object>> out = new ArrayList<>();
        for (String n : names) {
            ColumnMeta x = ac.get(n), y = bc.get(n);
            Map<String, Object> row = new LinkedHashMap<>();
            row.put("name", x != null ? x.name() : y.name());
            if (x == null || y == null) {
                row.put("status", x == null ? "right" : "left");
                row.put("changed", true); row.put("definitionChanged", false); row.put("orderChanged", false);
                row.put("properties", List.of());
                out.add(row); continue;
            }
            List<Map<String, Object>> props = new ArrayList<>();
            addProp(props, "Column Name", x.name(), y.name(), !same(x.name(), y.name(), ignoreCase));
            addProp(props, "#", String.valueOf(x.ordinal()), String.valueOf(y.ordinal()), x.ordinal() != y.ordinal());
            String xt = displayType(x), yt = displayType(y);
            TypeResult type = compareType(x, y);
            addProp(props, "Type", xt, yt, type.different);
            addProp(props, "Length", String.valueOf(x.size()), String.valueOf(y.size()), x.size() != y.size() && !type.equivalentSize);
            addProp(props, "Scale", String.valueOf(x.scale()), String.valueOf(y.scale()), x.scale() != y.scale() && !type.equivalentNumeric);
            addProp(props, "Not Null", String.valueOf(!x.nullable()), String.valueOf(!y.nullable()), x.nullable() != y.nullable());
            addProp(props, "Default", nullToDash(x.defaultValue()), nullToDash(y.defaultValue()),
                    !normalizeDefault(x.defaultValue()).equals(normalizeDefault(y.defaultValue())));
            boolean orderChanged = x.ordinal() != y.ordinal();
            boolean definitionChanged = props.stream().anyMatch(p -> !"#".equals(p.get("name"))
                    && !"Column Name".equals(p.get("name")) && Boolean.TRUE.equals(p.get("different")));
            boolean changed = definitionChanged || orderChanged;
            row.put("status", "both"); row.put("properties", props);
            row.put("definitionChanged", definitionChanged); row.put("orderChanged", orderChanged);
            row.put("changed", changed); row.put("typeReview", type.review);
            out.add(row);
        }
        return out;
    }

    private static List<Map<String, Object>> compareIndexes(TableMeta a, TableMeta b, boolean ignoreCase) {
        Map<String, IndexMeta> x = indexSignatureMap(a.indexes(), ignoreCase);
        Map<String, IndexMeta> y = indexSignatureMap(b.indexes(), ignoreCase);
        Set<String> keys = new TreeSet<>(); keys.addAll(x.keySet()); keys.addAll(y.keySet());
        List<Map<String, Object>> out = new ArrayList<>();
        for (String k : keys) {
            IndexMeta l = x.get(k), r = y.get(k);
            out.add(Map.of("signature", k, "left", l == null ? "N/A" : l.name() + " (" + String.join(", ", l.columns()) + ")",
                    "right", r == null ? "N/A" : r.name() + " (" + String.join(", ", r.columns()) + ")",
                    "status", l != null && r != null ? "MATCHED" : l != null ? "ONLY_LEFT" : "ONLY_RIGHT"));
        }
        return out;
    }

    private static List<Map<String, Object>> compareConstraints(TableMeta a, TableMeta b, boolean ignoreCase) {
        Map<String, String> x = constraintSignatureMap(a.constraints(), ignoreCase);
        Map<String, String> y = constraintSignatureMap(b.constraints(), ignoreCase);
        Set<String> keys = new TreeSet<>(); keys.addAll(x.keySet()); keys.addAll(y.keySet());
        List<Map<String, Object>> out = new ArrayList<>();
        for (String k : keys) {
            String l = x.get(k), r = y.get(k);
            out.add(Map.of("signature", k, "left", l == null ? "N/A" : l,
                    "right", r == null ? "N/A" : r,
                    "status", l != null && r != null ? "MATCHED" : l != null ? "ONLY_LEFT" : "ONLY_RIGHT"));
        }
        return out;
    }

    private static Map<String, String> constraintSignatureMap(List<ConstraintMeta> list, boolean ignoreCase) {
        Map<String, String> m = new TreeMap<>();
        for (ConstraintMeta c : list) {
            String cols = String.join(",", c.columns()).toUpperCase(Locale.ROOT);
            String ref = c.referenceTable() == null ? "" : c.referenceTable().toUpperCase(Locale.ROOT)
                    + "(" + String.join(",", c.referenceColumns()).toUpperCase(Locale.ROOT) + ")";
            String sig = c.type() + "|" + cols + "|" + ref;
            m.put(sig, c.name() + " · " + c.type() + " · " + cols + (ref.isEmpty() ? "" : " → " + ref));
        }
        return m;
    }

    private static Map<String, IndexMeta> indexSignatureMap(List<IndexMeta> list, boolean ignoreCase) {
        Map<String, IndexMeta> m = new TreeMap<>();
        for (IndexMeta i : list) {
            String sig = (i.unique() ? "UNIQUE|" : "NON_UNIQUE|")
                    + String.join(",", i.columns()).toUpperCase(Locale.ROOT);
            m.put(sig, i);
        }
        return m;
    }

    private static Map<String, ColumnMeta> columnMap(List<ColumnMeta> list, boolean ignoreCase) {
        Map<String, ColumnMeta> m = new TreeMap<>();
        for (ColumnMeta c : list) m.put(ignoreCase ? c.name().toUpperCase(Locale.ROOT) : c.name(), c);
        return m;
    }

    private static void addProp(List<Map<String, Object>> props, String name, String left, String right, boolean diff) {
        Map<String, Object> p = new LinkedHashMap<>();
        p.put("name", name); p.put("left", nullToDash(left)); p.put("right", nullToDash(right)); p.put("different", diff);
        props.add(p);
    }
    private static String nullToDash(String s) { return s == null || s.isBlank() ? "—" : s.trim(); }
    private static String normalizeDefault(String s) { return s == null ? "" : s.trim().replaceAll("\\s+", " ").toUpperCase(Locale.ROOT); }
    private static boolean same(String a, String b, boolean ignoreCase) {
        return ignoreCase ? a.equalsIgnoreCase(b) : a.equals(b);
    }
    private static String displayType(ColumnMeta c) {
        String t = c.typeName() == null ? "UNKNOWN" : c.typeName().toUpperCase(Locale.ROOT);
        if (t.contains("CHAR") || t.contains("BINARY") || t.equals("RAW")) return t + "(" + c.size() + ")";
        if (t.contains("NUMBER") || t.contains("NUMERIC") || t.contains("DECIMAL")) {
            if (c.size() > 0 && c.scale() >= 0 && c.scale() < 100) return t + "(" + c.size() + "," + c.scale() + ")";
        }
        return t;
    }
    private static TypeResult compareType(ColumnMeta a, ColumnMeta b) {
        String x = canonical(a.typeName()), y = canonical(b.typeName());
        if (x.equals(y)) return new TypeResult(false, false, false, false);
        if (Set.of("VARCHAR", "CHARACTER VARYING").contains(x) && Set.of("VARCHAR", "CHARACTER VARYING").contains(y))
            return new TypeResult(false, true, a.size() != b.size(), false);
        if ((x.equals("NUMERIC") || x.equals("DECIMAL")) && (y.equals("NUMERIC") || y.equals("DECIMAL")))
            return new TypeResult(false, false, false, false);
        if (x.equals("TEXT") && (y.equals("CLOB") || y.equals("NCLOB")) || y.equals("TEXT") && (x.equals("CLOB") || x.equals("NCLOB")))
            return new TypeResult(false, true, false, false);
        if (x.equals("BYTEA") && (y.equals("BLOB") || y.equals("LONG RAW")) || y.equals("BYTEA") && (x.equals("BLOB") || x.equals("LONG RAW")))
            return new TypeResult(false, true, false, false);
        boolean numericAmbiguous = Set.of("NUMBER", "NUMERIC", "DECIMAL", "BIGINT", "INTEGER", "INT").contains(x)
                && Set.of("NUMBER", "NUMERIC", "DECIMAL", "BIGINT", "INTEGER", "INT").contains(y);
        return new TypeResult(true, false, false, false, numericAmbiguous);
    }
    private static String canonical(String t) {
        if (t == null) return "UNKNOWN";
        String s = t.toUpperCase(Locale.ROOT).trim();
        return switch (s) {
            case "VARCHAR2", "NVARCHAR2", "CHARACTER VARYING" -> "VARCHAR";
            case "NCHAR" -> "CHAR";
            case "FLOAT8" -> "DOUBLE PRECISION";
            case "INT8" -> "BIGINT";
            case "INT4" -> "INTEGER";
            case "BOOL" -> "BOOLEAN";
            default -> s;
        };
    }
    private record TypeResult(boolean different, boolean equivalentSize, boolean equivalentNumeric, boolean unused, boolean review) {
        TypeResult(boolean different, boolean equivalentSize, boolean equivalentNumeric, boolean unused) {
            this(different, equivalentSize, equivalentNumeric, unused, false);
        }
    }
}
class Html {
    static String escape(String s) {
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
                .replace("\"", "&quot;").replace("'", "&#39;");
    }
}
