CREATE TABLE user_info (id BIGINT NOT NULL, user_name VARCHAR(200), amount NUMERIC(14,2), created_at TIMESTAMP, email VARCHAR(255));
