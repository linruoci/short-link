# Oracle vs PostgreSQL DB Compare POC

Java 17 + Liquibase 4.33.0 + JDBC. This is a small read-only POC:
- Liquibase compares supported schema objects and produces its native text diff.
- JDBC `DatabaseMetaData` separately compares table columns, including `TYPE_NAME`,
  `COLUMN_SIZE`, `DECIMAL_DIGITS`, nullability and default value.
- An HTML report is written to `target/db-compare-report.html`.

> This POC does not execute DDL or modify either database.

## 1. Configure environment variables

PowerShell example (replace values with your own):

```powershell
$env:REF_URL="jdbc:oracle:thin:@//localhost:1521/ORCLPDB1"
$env:REF_USER="APP_USER"
$env:REF_PASSWORD="your_password"
$env:REF_SCHEMA="APP_USER"

$env:CMP_URL="jdbc:postgresql://localhost:5432/testdb"
$env:CMP_USER="postgres"
$env:CMP_PASSWORD="your_password"
$env:CMP_SCHEMA="public"

mvn clean compile exec:java
```

Linux/macOS:

```bash
export REF_URL='jdbc:oracle:thin:@//localhost:1521/ORCLPDB1'
export REF_USER='APP_USER'
export REF_PASSWORD='your_password'
export REF_SCHEMA='APP_USER'

export CMP_URL='jdbc:postgresql://localhost:5432/testdb'
export CMP_USER='postgres'
export CMP_PASSWORD='your_password'
export CMP_SCHEMA='public'

mvn clean compile exec:java
```

The report is generated at `target/db-compare-report.html`.

## 2. Test data suggestion

Create the same logical table in both databases, but deliberately introduce differences.

Oracle:

```sql
CREATE TABLE USER_INFO (
  ID NUMBER(10) NOT NULL,
  USER_NAME VARCHAR2(100),
  AMOUNT NUMBER(12,2),
  CREATED_AT TIMESTAMP
);
```

PostgreSQL:

```sql
CREATE TABLE user_info (
  id BIGINT NOT NULL,
  user_name VARCHAR(200),
  amount NUMERIC(14,2),
  created_at TIMESTAMP,
  email VARCHAR(255)
);
```

The JDBC section should identify the column differences and the additional `EMAIL` column.
Liquibase's own diff is shown separately in the report.

## 3. Important notes

- The reference side is Oracle; the comparison side is PostgreSQL.
- `Missing` means present in Oracle/reference but absent in PostgreSQL/comparison.
- `Unexpected` means present in PostgreSQL/comparison but absent in Oracle/reference.
- Schema names may differ; set `REF_SCHEMA` and `CMP_SCHEMA` to the actual schema names.
- Object-name matching across vendors can be affected by case-folding and naming rules.
  This POC normalizes table/column names to uppercase for the JDBC column comparison.
- Liquibase's official `diff` documentation says it does not currently compare datatype length.
  Therefore the JDBC metadata comparison is intentionally included; validate vendor-specific
  metadata behavior against your actual Oracle/PostgreSQL versions.
- Oracle `NUMBER` and PostgreSQL `NUMERIC`, `VARCHAR2` and `VARCHAR` are not necessarily
  semantically equivalent just because their metadata values look similar. This POC reports
  raw metadata differences and does not attempt to infer business-level type equivalence.
- Keep credentials out of source control. Use environment variables or a secrets manager.
