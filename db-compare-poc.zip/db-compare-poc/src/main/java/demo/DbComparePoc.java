package demo;

import liquibase.database.Database;
import liquibase.database.DatabaseFactory;
import liquibase.database.jvm.JdbcConnection;
import liquibase.diff.DiffGeneratorFactory;
import liquibase.diff.DiffResult;
import liquibase.diff.output.report.DiffToReport;
import liquibase.diff.compare.CompareControl;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.*;
import java.util.*;

public class DbComparePoc {

    public static void main(String[] args) throws Exception {
        Config cfg = Config.fromEnvironment();

        String liquibaseText = runLiquibaseDiff(cfg);
        List<ColumnDiff> columnDiffs = compareColumns(cfg);

        String html = HtmlReport.render(
                cfg.refSchema, cfg.cmpSchema, liquibaseText, columnDiffs);

        Path output = Path.of("target", "db-compare-report.html");
        Files.createDirectories(output.getParent());
        Files.writeString(output, html, StandardCharsets.UTF_8);

        long different = columnDiffs.stream()
                .filter(d -> !"MATCH".equals(d.status)).count();

        System.out.println("Liquibase diff completed.");
        System.out.println("Column rows: " + columnDiffs.size()
                + ", non-matching rows: " + different);
        System.out.println("HTML report: " + output.toAbsolutePath());
    }

    /**
     * Liquibase schema-object comparison. This does not execute any changes.
     */
    private static String runLiquibaseDiff(Config c) throws Exception {
        Database reference = null;
        Database comparison = null;
        try {
            Connection refConn = DriverManager.getConnection(
                    c.refUrl, c.refUser, c.refPassword);
            Connection cmpConn = DriverManager.getConnection(
                    c.cmpUrl, c.cmpUser, c.cmpPassword);

            reference = DatabaseFactory.getInstance()
                    .findCorrectDatabaseImplementation(new JdbcConnection(refConn));
            comparison = DatabaseFactory.getInstance()
                    .findCorrectDatabaseImplementation(new JdbcConnection(cmpConn));

            reference.setDefaultSchemaName(c.refSchema);
            comparison.setDefaultSchemaName(c.cmpSchema);

            CompareControl control = new CompareControl();
            DiffResult result = DiffGeneratorFactory.getInstance()
                    .compare(reference, comparison, control);

            ByteArrayOutputStream buffer = new ByteArrayOutputStream();
            try (PrintStream ps = new PrintStream(buffer, true, StandardCharsets.UTF_8)) {
                new DiffToReport(result, ps).print();
            }
            return buffer.toString(StandardCharsets.UTF_8);
        } finally {
            if (reference != null) {
                try { reference.close(); } catch (Exception ignored) { }
            }
            if (comparison != null) {
                try { comparison.close(); } catch (Exception ignored) { }
            }
        }
    }

    /**
     * JDBC supplement: compare column metadata, including length/precision.
     * Reference = Oracle, comparison = PostgreSQL.
     */
    private static List<ColumnDiff> compareColumns(Config c) throws SQLException {
        try (Connection ref = DriverManager.getConnection(c.refUrl, c.refUser, c.refPassword);
             Connection cmp = DriverManager.getConnection(c.cmpUrl, c.cmpUser, c.cmpPassword)) {

            Map<String, ColumnMeta> refColumns = loadColumns(ref, c.refSchema);
            Map<String, ColumnMeta> cmpColumns = loadColumns(cmp, c.cmpSchema);

            SortedSet<String> keys = new TreeSet<>();
            keys.addAll(refColumns.keySet());
            keys.addAll(cmpColumns.keySet());

            List<ColumnDiff> result = new ArrayList<>();
            for (String key : keys) {
                ColumnMeta left = refColumns.get(key);
                ColumnMeta right = cmpColumns.get(key);

                if (left == null) {
                    result.add(new ColumnDiff(key, "-", right.describe(), "ADDED"));
                } else if (right == null) {
                    result.add(new ColumnDiff(key, left.describe(), "-", "MISSING"));
                } else if (left.sameAs(right)) {
                    result.add(new ColumnDiff(key, left.describe(), right.describe(), "MATCH"));
                } else {
                    result.add(new ColumnDiff(key, left.describe(), right.describe(), "DIFFERENT"));
                }
            }
            return result;
        }
    }

    private static Map<String, ColumnMeta> loadColumns(Connection connection, String schema)
            throws SQLException {
        DatabaseMetaData md = connection.getMetaData();
        Map<String, ColumnMeta> result = new TreeMap<>();

        try (ResultSet tables = md.getTables(connection.getCatalog(), schema, "%",
                new String[]{"TABLE"})) {
            while (tables.next()) {
                String table = tables.getString("TABLE_NAME");
                String tableSchema = tables.getString("TABLE_SCHEM");
                try (ResultSet columns = md.getColumns(
                        connection.getCatalog(), tableSchema, table, "%")) {
                    while (columns.next()) {
                        String column = columns.getString("COLUMN_NAME");
                        ColumnMeta meta = new ColumnMeta(
                                table,
                                column,
                                columns.getString("TYPE_NAME"),
                                columns.getInt("COLUMN_SIZE"),
                                nullableText(columns.getInt("NULLABLE")),
                                columns.getString("COLUMN_DEF"),
                                columns.getInt("DECIMAL_DIGITS")
                        );
                        result.put(normalize(table) + "." + normalize(column), meta);
                    }
                }
            }
        }
        return result;
    }

    private static String nullableText(int nullable) {
        return switch (nullable) {
            case DatabaseMetaData.columnNoNulls -> "NOT NULL";
            case DatabaseMetaData.columnNullable -> "NULL";
            default -> "UNKNOWN";
        };
    }

    private static String normalize(String value) {
        return value == null ? "" : value.toUpperCase(Locale.ROOT);
    }

    private record Config(
            String refUrl, String refUser, String refPassword, String refSchema,
            String cmpUrl, String cmpUser, String cmpPassword, String cmpSchema) {

        static Config fromEnvironment() {
            return new Config(
                    required("REF_URL"), required("REF_USER"),
                    required("REF_PASSWORD"), required("REF_SCHEMA"),
                    required("CMP_URL"), required("CMP_USER"),
                    required("CMP_PASSWORD"), required("CMP_SCHEMA")
            );
        }

        private static String required(String name) {
            String value = System.getenv(name);
            if (value == null || value.isBlank()) {
                throw new IllegalArgumentException("Missing environment variable: " + name);
            }
            return value;
        }
    }

    private record ColumnMeta(
            String table, String column, String typeName, int size,
            String nullable, String defaultValue, int scale) {

        String describe() {
            return "type=" + safe(typeName)
                    + ", size=" + size
                    + ", scale=" + scale
                    + ", nullable=" + nullable
                    + ", default=" + safe(defaultValue);
        }

        boolean sameAs(ColumnMeta other) {
            return Objects.equals(normalize(typeName), normalize(other.typeName))
                    && size == other.size
                    && scale == other.scale
                    && Objects.equals(nullable, other.nullable)
                    && Objects.equals(normalize(defaultValue), normalize(other.defaultValue));
        }

        private static String safe(String value) {
            return value == null ? "(null)" : value;
        }
    }

    static record ColumnDiff(String name, String reference, String comparison, String status) {}
}
