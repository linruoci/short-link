package demo;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

final class HtmlReport {
    private HtmlReport() {}

    static String render(String refSchema, String cmpSchema,
                         String liquibaseText, List<DbComparePoc.ColumnDiff> diffs) {
        long added = diffs.stream().filter(d -> "ADDED".equals(d.status())).count();
        long missing = diffs.stream().filter(d -> "MISSING".equals(d.status())).count();
        long changed = diffs.stream().filter(d -> "DIFFERENT".equals(d.status())).count();
        long matched = diffs.stream().filter(d -> "MATCH".equals(d.status())).count();

        StringBuilder rows = new StringBuilder();
        for (DbComparePoc.ColumnDiff d : diffs) {
            rows.append("<tr class=\"").append(css(d.status())).append("\">")
                    .append(td(d.name()))
                    .append(td(d.reference()))
                    .append(td(d.comparison()))
                    .append(td(d.status()))
                    .append("</tr>\n");
        }

        return """
                <!doctype html>
                <html lang="en">
                <head>
                  <meta charset="utf-8">
                  <meta name="viewport" content="width=device-width, initial-scale=1">
                  <title>Database Compare Report</title>
                  <style>
                    body{font:14px/1.5 Arial,sans-serif;margin:28px;color:#222;background:#f7f8fa}
                    h1,h2{margin-bottom:8px} .muted{color:#666}
                    .summary{display:flex;gap:12px;flex-wrap:wrap;margin:18px 0}
                    .card{background:white;border:1px solid #ddd;border-radius:8px;padding:12px 18px;min-width:105px}
                    .num{font-size:24px;font-weight:bold}
                    table{border-collapse:collapse;width:100%;background:white}
                    th,td{border:1px solid #ddd;padding:9px;text-align:left;vertical-align:top}
                    th{background:#edf0f4;position:sticky;top:0}
                    tr.ADDED{background:#effaf1} tr.MISSING{background:#fff1f0}
                    tr.DIFFERENT{background:#fff9e8} tr.MATCH{background:#fff}
                    code,pre{font-family:Consolas,monospace}
                    pre{white-space:pre-wrap;overflow-wrap:anywhere;background:#17191d;color:#eee;padding:16px;border-radius:8px}
                    .wrap{overflow-x:auto}
                  </style>
                </head>
                <body>
                  <h1>Database Compare Report</h1>
                  <div class="muted">Generated: %s</div>
                  <p>Reference schema: <b>%s</b> &nbsp; | &nbsp; Comparison schema: <b>%s</b></p>
                  <div class="summary">
                    <div class="card"><div class="num">%d</div>Matched</div>
                    <div class="card"><div class="num">%d</div>Different</div>
                    <div class="card"><div class="num">%d</div>Added on comparison</div>
                    <div class="card"><div class="num">%d</div>Missing on comparison</div>
                  </div>
                  <h2>Column metadata comparison (JDBC)</h2>
                  <p class="muted">Type name, size, scale, nullability and default value are compared as raw metadata.</p>
                  <div class="wrap">
                    <table>
                      <thead><tr><th>Table.Column</th><th>Reference (Oracle)</th>
                      <th>Comparison (PostgreSQL)</th><th>Status</th></tr></thead>
                      <tbody>%s</tbody>
                    </table>
                  </div>
                  <h2>Liquibase schema diff</h2>
                  <pre>%s</pre>
                </body>
                </html>
                """.formatted(escape(LocalDateTime.now().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME)),
                escape(refSchema), escape(cmpSchema), matched, changed, added, missing,
                rows, escape(liquibaseText));
    }

    private static String css(String status) { return status; }
    private static String td(String value) { return "<td>" + escape(value) + "</td>"; }

    private static String escape(String value) {
        if (value == null) return "";
        return value.replace("&", "&amp;").replace("<", "&lt;")
                .replace(">", "&gt;").replace("\"", "&quot;")
                .replace("'", "&#39;");
    }
}
